
a: str
a = "abc"
a = 123
a = 123.456
print(f"{a = }")

b: float
b = "abc"
b = 123
b = 123.456
print(f"{b = }")
